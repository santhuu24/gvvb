package com.cg.dto;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="roomdetails")

public class RoomDto{
	@Column(name="hotel_id")
	@Length(min=4,max=4,message="Should be 4 letters")
	private int hotelId;
	@Id
	@Column(name="room_id")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq", sequenceName="room_seq")
	@Length(min=4,max=4,message="Should be 4 letters")
	private int roomId;
	@Column(name="room_Type")
	@NotEmpty(message="Room Type cannot be empty(Ac/NON-AC)")
	private String roomType;
	@NotNull
	@Min(value=1,message="Minimum value should be Rs.1")
	@Column(name="per_Night_Rate")
	private float perNightRate;
	@Column(name="availability")
	private String availability;

	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public String getRoomType() {
		return roomType;
	}
	@Override
	public String toString() {
		return "RoomDto [hotelId=" + hotelId + ", roomId=" + roomId + ", roomType=" + roomType + ", perNightRate="
				+ perNightRate + ", availability=" + availability + "]";
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public float getPerNightRate() {
		return perNightRate;
	}
	public void setPerNightRate(float perNightRate) {
		this.perNightRate = perNightRate;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}

}
