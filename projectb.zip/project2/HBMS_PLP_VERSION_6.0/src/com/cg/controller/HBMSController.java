package com.cg.controller;



import java.util.ArrayList;




import java.util.Date;
import java.util.List;

import javax.enterprise.inject.Model;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.BookingsDto;
import com.cg.dto.HotelDto;
import com.cg.dto.LoginDto;
import com.cg.dto.RoomDto;
import com.cg.exception.HotelException;
import com.cg.service.IHBMSService;

@Controller
public class HBMSController {
	private static final Logger logr = Logger.getLogger(HBMSController.class);
	
	ModelAndView mv;
	@Autowired
	IHBMSService hbmsService;
	@RequestMapping("/")
	public ModelAndView first()
	{
		

		mv =new ModelAndView("login");

		mv.addObject("login", new LoginDto());

		return mv;

	}
	@SuppressWarnings("finally")
	@RequestMapping("/validateLogin")
	public ModelAndView validateLogin(@ModelAttribute("login") @Valid LoginDto dto,BindingResult result){

		if(result.hasErrors())
		{
			mv = new ModelAndView("login");

		}
		boolean validateLogin;
		try {
			validateLogin = hbmsService.validateLogin(dto.getUserid(),dto.getPassword());
			if(validateLogin){
				logr.info("Login Success");
				mv = new ModelAndView("success");

			}
			else
			{
				logr.error("Login Error");
				mv = new ModelAndView("login");
				mv.addObject("exception","Enter valid login details");

			}
		} catch (HotelException e) {
			mv=new ModelAndView("login");
			mv.addObject("exception",e.getMessage());

		}
		finally{
			return mv;
		}


	}
	@SuppressWarnings("finally")
	@RequestMapping("/hotelManagement")
	public ModelAndView hotelManagementOperations()
	{
		List<HotelDto> hotelList;
		try {
			logr.info("Hotel Management operation");
			
			hotelList = hbmsService.getAllHotels();
			mv = new ModelAndView("hotelManagement");
			mv.addObject("hotelList",hotelList);


		} catch (HotelException e) {
			logr.error("Error in Hotel Management operation");
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());

		}
		finally{
			return mv;
		}

	}
	@RequestMapping("/home")
	public ModelAndView home()
	{

		mv = new ModelAndView("success");
		return mv;

	}

	@RequestMapping(value="/addHotel",method=RequestMethod.POST)
	public ModelAndView addHotel()
	{
		mv = new ModelAndView("addHotel");
		ArrayList<String>	cityList=new ArrayList<String>();
		cityList.add("Anantapur");
		cityList.add("Hyderabad");
		cityList.add("Bangalore");
		cityList.add("Chennai");
		cityList.add("Kolkata");
		cityList.add("Noida");
		cityList.add("Pune");
		cityList.add("Goa");
		cityList.add("Vizag");
		cityList.add("New Delhi");
		cityList.add("Maisore");
		cityList.add("Nellore");
		cityList.add("Medchal");
		mv.addObject("cityList",cityList);

		ArrayList<String>	rating=new ArrayList<String>();
		rating.add("Good");
		rating.add("Average");
		rating.add("Poor");
		mv.addObject("rating", rating);
		mv.addObject("add", new HotelDto());
		return mv;

	}
	@RequestMapping("/addHotelData")
	public ModelAndView addHotelData(@ModelAttribute("add") @Valid HotelDto hotelDto,BindingResult result)
	{	

		if(result.hasErrors()){
			mv=new ModelAndView("addHotel");
			ArrayList<String>	cityList=new ArrayList<String>();
			cityList.add("Anantapur");
			cityList.add("Hyderabad");
			cityList.add("Bangalore");
			cityList.add("Chennai");
			cityList.add("Kolkata");
			cityList.add("Noida");
			cityList.add("Pune");
			cityList.add("Goa");
			cityList.add("Vizag");
			cityList.add("New Delhi");
			cityList.add("Maisore");
			cityList.add("Nellore");
			cityList.add("Medchal");
			mv.addObject("cityList",cityList);

			ArrayList<String>	rating=new ArrayList<String>();
			rating.add("Good");
			rating.add("Average");
			rating.add("Poor");
			mv.addObject("rating", rating);

			return mv;
		}
		else{

			try {
				hbmsService.addNewHotel(hotelDto);
				List<HotelDto> hotelList=hbmsService.getAllHotels();
				mv = new ModelAndView("hotelManagement");
				mv.addObject("hotelList",hotelList);
				return mv;

			} catch (HotelException e) {

				mv=new ModelAndView("error");
				mv.addObject("exception",e.getMessage());
				return mv;
			}


		}


	}
	@RequestMapping("/deleteHotel")
	public ModelAndView deleteHotel(@RequestParam("hId")int hotelId){

		System.out.println("in controll");
		try{
			System.out.println("in tru11");
			hbmsService.deleteHotel(hotelId);
			System.out.println("In controler try");
			List<HotelDto> hotelList=hbmsService.getAllHotels();
			mv = new ModelAndView("hotelManagement");
			mv.addObject("hotelList",hotelList);
			return mv;
		}catch(HotelException e){

			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
			return mv;
		}


	}
	@RequestMapping("/updateHotel")
	public ModelAndView updateHotel(@RequestParam("hId")int hotelId){
		HotelDto hotelData;
		try {
			hotelData = hbmsService.retrieveHotelData(hotelId);
			mv = new ModelAndView("update");
			ArrayList<String>	cityList=new ArrayList<String>();
			cityList.add("Anantapur");
			cityList.add("Hyderabad");
			cityList.add("Bangalore");
			cityList.add("Chennai");
			cityList.add("Kolkata");
			cityList.add("Noida");
			cityList.add("Pune");
			cityList.add("Goa");
			cityList.add("Vizag");
			cityList.add("New Delhi");
			cityList.add("Maisore");
			cityList.add("Nellore");
			cityList.add("Medchal");
			mv.addObject("cityList",cityList);

			ArrayList<String>	rating=new ArrayList<String>();
			rating.add("Good");
			rating.add("Average");
			rating.add("Poor");
			mv.addObject("rating", rating);



			mv.addObject("hotelData",hotelData);
			mv.addObject("update", new HotelDto());
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
			return mv;
		}

		return mv;

	}
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public ModelAndView updateHotel(@ModelAttribute("update") @Valid HotelDto hotel,BindingResult result){
		HotelDto hotelData;
		try {
			hotelData = hbmsService.retrieveHotelData(hotel.getHotelId());
			if(result.hasErrors()){

				mv=new ModelAndView("update");
				ArrayList<String>	cityList=new ArrayList<String>();
				cityList.add("Anantapur");
				cityList.add("Hyderabad");
				cityList.add("Bangalore");
				cityList.add("Chennai");
				cityList.add("Kolkata");
				cityList.add("Noida");
				cityList.add("Pune");
				cityList.add("Goa");
				cityList.add("Vizag");
				cityList.add("New Delhi");
				cityList.add("Maisore");
				cityList.add("Nellore");
				cityList.add("Medchal");
				mv.addObject("cityList",cityList);

				ArrayList<String>	rating=new ArrayList<String>();
				rating.add("Good");
				rating.add("Average");
				rating.add("Poor");
				mv.addObject("rating", rating);
				mv.addObject("hotelData",hotelData);

			}else{



				try {
					System.out.println(hotel.toString());
					hbmsService.updateHotel(hotel);

					List<HotelDto> hotelList;

					hotelList = hbmsService.getAllHotels();
					mv = new ModelAndView("hotelManagement");
					mv.addObject("hotelList",hotelList);

				} catch (HotelException e) {
					mv=new ModelAndView("error");
					mv.addObject("exception",e.getMessage());

				}
			}
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());

		}
		return mv;

	}


	//Room management
	@RequestMapping("/roomManagement")
	public ModelAndView roomManagementOperations()
	{
		List<HotelDto> hotelList;
		try {
			hotelList = hbmsService.getAllHotels();
			mv = new ModelAndView("roomManagement");
			mv.addObject("hotelList",hotelList);
			return mv;

		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
			return mv;
		}

	}

	@RequestMapping("/hotelRooms")
	public ModelAndView hotelRooms(@RequestParam("hId") int hotelId){

		List<RoomDto> hotelRooms;
		try {
			hotelRooms = hbmsService.getAllRooms(hotelId);
			mv = new ModelAndView("hotelRooms");
			mv.addObject("hotelRooms",hotelRooms);
			mv.addObject("hotelId", hotelId);
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
		}


		return mv;





	}



	//Add room

	@RequestMapping("/deleteRooms")
	public ModelAndView deleteRoom(@RequestParam("hId") int hotelId,@RequestParam("rId") int roomId){


		try {
			hbmsService.deleteRoom(roomId);
			List<RoomDto> hotelRooms = hbmsService.getAllRooms(hotelId);
			mv = new ModelAndView("hotelRooms");


			mv.addObject("hotelRooms",hotelRooms);
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
		}


		return mv;


	}

	@RequestMapping("/addRoom")
	public ModelAndView addRoom(@RequestParam("hId") int hotelId)
	{
		System.out.println("In add rokom  "+hotelId);
		mv = new ModelAndView("addRoom");
		mv.addObject("addRoom", new RoomDto());
		mv.addObject("hotelId",hotelId);
		return mv;

	}
	@RequestMapping("/addRoomData")
	public ModelAndView addRoomData(@ModelAttribute("addRoom")  RoomDto roomDto) 
	{
		System.out.println("before"+roomDto);
		try {
			hbmsService.addNewRoom(roomDto);
			List<RoomDto> hotelRooms = hbmsService.getAllRooms(roomDto.getHotelId());
			mv = new ModelAndView("hotelRooms");
			mv.addObject("hotelRooms",hotelRooms);
			mv.addObject("hotelId",roomDto.getHotelId());
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
		}

		return mv;
	} 


	@RequestMapping("/viewDetails")
	public ModelAndView viewDetails() 
	{
		mv = new ModelAndView("viewDetails");
		return mv;

	}
	@RequestMapping("/searchHotel")
	public ModelAndView searchHotel() 
	{
		mv = new ModelAndView("searchHotel");
		return mv;

	}
	@RequestMapping("/searchHotelById")
	public ModelAndView searchHotelById(@RequestParam("hotelId") @Valid int hotelId,BindingResult result){                         //   @ModelAttribute("login") @Valid LoginDto dto,BindingResult result
		HotelDto hotelData;
		if(result.hasErrors())
		{
			mv = new ModelAndView("searchHotel");

		}
		else
		{
			try {
				hotelData = hbmsService.retrieveHotelData(hotelId);
				mv = new ModelAndView("specificHotelDetails");

				mv.addObject("hotelData",hotelData);
			} catch (HotelException e) {
				mv=new ModelAndView("error");
				mv.addObject("exception",e.getMessage());
			}

		}
		return mv;

	}
	@RequestMapping("/searchRoom")
	public ModelAndView searchRoom() 
	{
		mv = new ModelAndView("searchRoom");
		return mv;

	}

	@RequestMapping("/searchRoomById")
	public ModelAndView searchRoomById(@RequestParam("roomId")int roomId){
		RoomDto roomData;
		try {
			roomData = hbmsService.retrieveRoomDataById(roomId);
			mv = new ModelAndView("specificRoomDetails");

			mv.addObject("roomData",roomData);
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
		}


		return mv;

	}


	@RequestMapping("/updateRoomsById")
	public ModelAndView updateRooms(@RequestParam("hId") int hotelId,@RequestParam("rId") int roomId){

		RoomDto roomDto;
		try {
			roomDto = hbmsService.updateRooms(roomId);
			ModelAndView mv=new ModelAndView("updateRooms");
			mv.addObject("roomDto",roomDto);
			mv.addObject("updateRoom", new RoomDto());
			return mv;
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
			return mv;
		}

		

	}

	@RequestMapping("/updateOneRoom")
	public ModelAndView updateOneRoom(@ModelAttribute("updateRoom")  RoomDto roomDto){

		List<RoomDto> hotelRooms;
		try {
			hbmsService.upadateRoomDetails(roomDto);
			hotelRooms = hbmsService.getAllRooms(roomDto.getHotelId());

			mv = new ModelAndView("hotelRooms");
			mv.addObject("hotelRooms",hotelRooms);
			return mv;
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
			return mv;
		}


		

	}

	@RequestMapping("/viewListOfHotels")
	public ModelAndView viewAllHotels(){
		List<HotelDto> hotelList;
		try {
			hotelList = hbmsService.getAllHotels();
			mv = new ModelAndView("viewAllHotels");
			mv.addObject("hotelList",hotelList);


		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());

		}
		return mv;
	}

	@RequestMapping("/bookingDetailsForSpecificDate")
	public ModelAndView bookingDetailsForSpecificDate(){

		ModelAndView mv=new ModelAndView("bookingDetailsForSpecificDate");
		mv.addObject("bookingDto", new BookingsDto());

		return mv;

	}

	@RequestMapping("/showDetailsForSpecificDate")
	public ModelAndView showDetailsForSpecificDate(@RequestParam("date") String specificDate) {

		List<BookingsDto> bookingsDto;
		try {
			bookingsDto = hbmsService.showDetailsForSpecificDate(specificDate);
			ModelAndView mv=new ModelAndView("displayBookingsForSpecificDate");
			mv.addObject("bookingsDto",bookingsDto);
			return mv;
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
			return mv;

		}

	


	}

	@RequestMapping("/viewBookingsOfSpecificHotel")
	public ModelAndView viewBookingsOfSpecificHotel(){
		ModelAndView mv=new ModelAndView("viewBookingsOfSpecificHotel");
		mv.addObject("bookingsDto", new BookingsDto());

		return mv;

	}

	@RequestMapping("/displayBookingsForSpecificHotel")
	public ModelAndView displayBookingsForSpecificHotel(@ModelAttribute("bookingsDto") @Valid BookingsDto book,BindingResult result){
		if(result.hasErrors())
		{
			mv = new ModelAndView("viewBookingsOfSpecificHotel");
			return mv;

		}

		else{

			List<BookingsDto> bookingsDto;
			try {
				
				bookingsDto = hbmsService.displayBookingsForSpecificHotel(book.getHotelId());
				
				ModelAndView mv=new ModelAndView("displayBookingsForSpecificHotel");
				if(bookingsDto.isEmpty())
				{
					mv.addObject("exception","No Bookings Available");
				}
				mv.addObject("bookingsDto",bookingsDto);
				return mv;
			} catch (HotelException e) {
				ModelAndView	mv=new ModelAndView("error");
				mv.addObject("exception",e.getMessage());

				return mv;

			}
		}

	}

	@RequestMapping("/viewGuestListOfSpecificHotel")
	public ModelAndView viewGuestListOfSpecificHotel(){

		ModelAndView mv=new ModelAndView("viewGuestListOfSpecificHotel");
		mv.addObject("bookingDto",new BookingsDto());
		return mv;

	}


	@RequestMapping("/displayGuestListOfSpecificHotel")
	public ModelAndView displayGuestListOfSpecificHotel(@RequestParam("hotelId") int hotelId){

		try {
			List<BookingsDto> bookingsDto=hbmsService.displayGuestListOfSpecificHotel(hotelId);
		} catch (HotelException e) {
			mv=new ModelAndView("error");
			mv.addObject("exception",e.getMessage());
		}


		return mv;

	}
	@RequestMapping("/logout")
	public ModelAndView logout()
	{

		mv =new ModelAndView("login");

		mv.addObject("login", new LoginDto());

		return mv;

	}
}

