package com.capgemini.lesson11;

public class MethodOverriding
{
  protected void add(int operand1, int operand2)
  {
     System.out.println(operand1 + operand2);
  }

}
