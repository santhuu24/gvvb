package com.cg.util;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import com.cg.exception.HotelException;



public class DBConnection {
	
	public static Connection ConnectToDB() throws HotelException {	
	Connection connection =null;
	Properties props=new Properties();
	FileReader reader;
	try {
		
		reader = new FileReader("jdbc.properties");
		props.load(reader);
		 Class.forName("oracle.jdbc.driver.OracleDriver");
		 
				return connection = DriverManager.getConnection(
						props.getProperty("dburl"),props.getProperty("username"),props.getProperty("password"));
				
	} catch (Exception e) {
		
		e.printStackTrace();
	}
	return connection;
	 
	}
}


