package com.cg.testcases;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Test;

import com.cg.bean.HotelBean;
import com.cg.exception.HotelException;
import com.cg.service.HotelServiceImpl;
import com.cg.service.IHotelService;

public class BookRoomTest {

	@Test
	public void testBookRoom() throws HotelException {
		IHotelService validateRole=new HotelServiceImpl();
		HotelBean bean=new  HotelBean();
		bean.setHotelId("1004");
		bean.setRoomId("abcd");
		bean.setUserId("1021");
		
		DateTimeFormatter dateFormatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate arrDate1=LocalDate.parse("17/09/2017",dateFormatter);
		Date sqlDate3=Date.valueOf(arrDate1);
		
		
		bean.setBookedFrom(sqlDate3);
		LocalDate arrDate2=LocalDate.parse("20/09/2017",dateFormatter);
		Date sqlDate4=Date.valueOf(arrDate2);
		
		
		bean.setBookedTo(sqlDate4);

		bean.setNoOfAdults("2");
		bean.setNoOfChildern("2");
		bean.setAmount(750);
		String userRole=validateRole.bookRoom(bean);
		assertEquals("ERROR", "1025", userRole);
	}

}
