package com.cg.testcases;

import static org.junit.Assert.*;

import org.junit.Test;


import com.cg.exception.HotelException;
import com.cg.service.HotelServiceImpl;
import com.cg.service.IHotelService;


	public class LoginTest {

		
		@Test
		public void testValidateLogin() throws HotelException {
			IHotelService validateRole=new HotelServiceImpl();
			boolean userRole=validateRole.validateUserDetails("1005", "abhi123");
			assertEquals("ERROR", true, userRole);
			
			boolean adminRole=validateRole.validateAdminDetails("1001", "admin");
			assertEquals("ERROR", true, adminRole);
			/*
			String executiveRole=validateRole.validateLogin("ravuri", "vamsi");
			assertEquals("ERROR", "EXECUTIVE", executiveRole);*/
		}

	}

