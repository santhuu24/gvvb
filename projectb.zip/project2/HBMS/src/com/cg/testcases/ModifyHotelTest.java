package com.cg.testcases;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.bean.HotelBean;
import com.cg.exception.HotelException;
import com.cg.service.HotelServiceImpl;
import com.cg.service.IHotelService;

public class ModifyHotelTest {

	@Test
	public void test() throws HotelException {
		IHotelService validateRole=new HotelServiceImpl();
		HotelBean bean=new  HotelBean();
		boolean userRole=validateRole.updateHotel("1004","helo");
		assertEquals("ERROR", true , userRole);
	}

}
