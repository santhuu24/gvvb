package com.cg.ui;

import org.apache.log4j.Logger;

public class LoggerFile {

	 static Logger logger=Logger.getLogger("LoggerFile.class");

}
	
