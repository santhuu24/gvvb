package com.cg.ui;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.HotelBean;
import com.cg.exception.HotelException;
import com.cg.service.HotelServiceImpl;
import com.cg.service.HotelValidation;
import com.cg.service.IHotelService;


public class HotelMain {
	static Logger logger=Logger.getLogger(HotelMain.class);
	public static void main(String[] args) throws HotelException  {
		HotelBean bean=new HotelBean();

		HotelValidation hotelValid =new HotelValidation();
		IHotelService hotelService= new HotelServiceImpl();
		PropertyConfigurator.configure("log4j.properties");
		try {


			String choice;
			Scanner scan=new Scanner(System.in);
			do{
				System.out.println("Hotel Booking Mangement System ");
				System.out.println("_______________________________\n");
				System.out.println("  1.User");
				System.out.println("  2.Admin");
				System.out.println("  3.Exit");
				System.out.println("________________________________");
				System.out.println("Select an option:");
				choice=scan.next();
				switch(choice){
				case "1":
					do{
						System.out.println("_______________USER________________\n");
						System.out.println("  1.Login");
						System.out.println("  2.Register");
						System.out.println("  3.Exit");
						System.out.println("_______________________________\n");
						System.out.println("Select an option:");
						choice=scan.next();
						switch(choice){
						case "1":
							System.out.println("Enter your user id with maximum 4 digits");
							String userId=scan.next();
							while(true){
								if(hotelValid.validateUserId(userId)){
									break;
								}else{
									System.err.println("Please enter numeric id with maximum 4 digits");
									userId=scan.next();
								}
							}
							System.out.println("Enter password without any spaces");
							String pwd=scan.next();
							while(true){
								if(hotelValid.validatePassword(pwd)){
									break;
								}else{
									System.err.println("Please enter password with minimum 2 and maximum 7 characters and no spaces");
									pwd=scan.next();
								}
							}
							boolean login=hotelService.validateUserDetails(userId, pwd);
							if(login==false){
								System.out.println("Wrong details");
								logger.error("wrong details");
							}
							else{
								logger.info("OPERATIONS");
								System.out.println("Welcome");
								do{
									System.out.println("_______________________________\n");
									System.out.println("OPERATIONS\n");
									System.out.println("_______________________________\n");
									System.out.println("  1.Search for rooms");
									System.out.println("  2.Book Hotel Rooms");
									System.out.println("  3.View Booking status ");
									System.out.println("  4.exit");
									System.out.println("Select an option:");
									choice=scan.next();/*
									String bookedFrom = null;*/
									switch(choice){
									case "1":
										logger.info("SEARCH ROOM");
										Scanner scanner3=new Scanner(System.in);
										System.out.println("Enter date from (dd/mm/yyyy)");
										String bookingFrom1=scanner3.next();
										Date fromDate1=hotelService.getSqlDate(bookingFrom1);
										while(true)
										{
											if(hotelValid.validateBookedFrom(fromDate1))
												break;
											else{
												System.err.println("Please enter valid date (dd/mm/yyyy)");
												bookingFrom1=scanner3.next();
												fromDate1=hotelService.getSqlDate(bookingFrom1);
											}

										}
										System.out.println("Enter date to dd/mm/yyyy");
										String bookingTo1=scanner3.next();
										Date toDate1=hotelService.getSqlDate(bookingTo1);
										while(true)
										{
											if(hotelValid.validateBookedFrom(toDate1))
												break;
											else{
												System.err.println("Please enter valid date (dd/mm/yyyy)");
												bookingTo1=scanner3.next();
												toDate1=hotelService.getSqlDate(bookingTo1);										}

										}
										ArrayList<HotelBean> flag=hotelService.searchRooms(fromDate1,toDate1);
										if(!flag.isEmpty())
										{
											System.out.println("HotelId  HotelName  RoomId  RoomType  RatePerNight City  Address Description  Phone1 Phone2 Rating Email Fax");
											for (HotelBean hotelBean : flag) {

												System.out.println(hotelBean.getHotelId()+"   "+hotelBean.getHotelName()+"  "+hotelBean.getRoomId()+"    "+hotelBean.getRoomType()+"  "+hotelBean.getRatePerNight()+"  "+hotelBean.getCity()+"  "+hotelBean.getHotelAddress()+" "+hotelBean.getDescription()+" "+hotelBean.getPhoneNo1()+" "+hotelBean.getPhoneNo2()+" " +hotelBean.getRating()+ " "+hotelBean.getEmail()+" "+hotelBean.getFax());
											}
										}
										else{
											System.out.println("No rooms are availabe for specified date.");

										}
										break;
									case "2":
										logger.info("BOOK ROOM");
										Scanner scanner=new Scanner(System.in);
										System.out.println("Enter the details to Book Hotel");
										System.out.println("Enter the hotel id");
										String hotelId=scanner.next();
										while(true){
											if(hotelValid.validateHotelId(hotelId)){
												break;
											}else{
												System.err.println("Please enter numeric id");
												hotelId=scan.next();
											}
										}
										bean.setHotelId(hotelId);
										System.out.println("Enter room id");
										String roomId=scanner.next();
										while(true){
											if(hotelValid.validateRoomId(roomId)){
												break;
											}else{
												System.err.println("Please enter numeric id");
												roomId=scan.next();
											}
										}
										bean.setRoomId(roomId);
										System.out.println("Enter your user id");
										String userId1=scanner.next();
										while(true){
											if(hotelValid.validateUserId(userId1)){
												break;
											}else{
												System.err.println("Please enter numeric id");
												userId1=scan.next();
											}
										}
										bean.setUserId(userId);
										System.out.println("Enter date from (dd/mm/yyyy)");
										String bookingFrom=scanner.next();
										Date fromDate=hotelService.getSqlDate(bookingFrom);
										while(true)
										{
											if(hotelValid.validateBookedFrom(fromDate))
												break;
											else{
												System.err.println("Please enter valid date (dd/mm/yyyy)");
												bookingFrom=scanner.next();
												fromDate=hotelService.getSqlDate(bookingFrom);										}

										}

										bean.setBookedFrom(fromDate);
										System.out.println("Enter date to dd/mm/yyyy");
										String bookingTo=scanner.next();
										Date toDate=hotelService.getSqlDate(bookingTo);
										while(true)
										{
											if(hotelValid.validateBookedFrom(toDate))
												break;
											else{
												System.err.println("Please enter valid date (dd/mm/yyyy)");
												bookingTo=scanner.next();
												toDate=hotelService.getSqlDate(bookingTo);										}

										}
										bean.setBookedTo(toDate);
										System.out.println("Enter number of childers");
										String NoOfChildren=scanner.next();
										while(true){
											if(hotelValid.validateNoOfChildren(NoOfChildren)){
												break;
											}else{
												System.err.println("Please enter number");
												NoOfChildren=scan.next();
											}
										}
										bean.setNoOfChildern(NoOfChildren);
										System.out.println("Enter number of adults");
										String NoOfAdults=scanner.next();
										while(true){
											if(hotelValid.validateNoOfAdults(NoOfAdults)){
												break;
											}else{
												System.err.println("Please enter number");
												NoOfAdults=scan.next();
											}
										}
										bean.setNoOfAdults(NoOfAdults);
										float amount=hotelService.getAmountByRoom(roomId,hotelId);
										float netAmount=hotelService.calculateAmount(fromDate,toDate,amount);
										bean.setAmount(netAmount);
										System.out.println("Your booking id is "+hotelService.bookRoom(bean));
										hotelService.changeAvailability(hotelId,roomId);
										break;
									case "3":
										logger.info("BOOKING STATUS");
										Scanner scanner1=new Scanner(System.in);
										System.out.println("Enter the booking id");
										String bookingId=scanner1.next();
										while(true){
											if(hotelValid.validateBookingId(bookingId)){
												break;
											}else{
												System.err.println("Please enter numeric id");
												bookingId=scan.next();
											}
										}
										HotelBean bean1=new HotelBean();
										bean1=hotelService.viewStatus(bookingId);
										if(bean1.getBookingId() != null){
											System.out.println(bean1.getBookingId()+" "+bean1.getHotelId()+" "+bean1.getRoomId()+" "+bean1.getUserId()+" "+bean1.getBookedFrom()+" "+bean1.getBookedTo()+" "+bean1.getNoOfAdults()+" "+bean1.getNoOfChildern()+" "+bean1.getAmount());
										}
										else{
											logger.error("please enter valid booking Id");;
										}
										break;
									case "4":
										logger.info("EXIT");
										System.out.println("Thank You, Please visit Again...");
										System.exit(0);
										break;
									default :
										System.out.println("Please choose valid option 1-4");
										break;
									}
								}while(choice!="4");
							}
							break;
						case "2":
							logger.info("WELCOME TO REGISTER PAGE");
							System.out.println("Please Enter the following details");
							System.out.println("Enter your name     :");
							String name=scan.next();
							while(true){
								if(hotelValid.validateName(name)){
									break;
								}else{
									System.err.println("Please enter valid name with minimum 3 alphabets");
									name=scan.next();
								}
							}
							bean.setUserName(name);
							System.out.println("Enter your mobile number     :");
							String mobileNumber=scan.next();
							while(true){
								if(hotelValid.validateMobileNumber(mobileNumber)){
									break;
								}else{
									System.err.println("Please enter mobile number with 10 digits");
									mobileNumber=scan.next();
								}
							}
							bean.setMobileNo(mobileNumber);
							System.out.println("Enter your phone number     :");
							String phoneNumber=scan.next();
							while(true){
								if(hotelValid.validatePhoneNumber(phoneNumber)){
									break;
								}else{
									System.err.println("Please enter Phone number with 10 digits");
									phoneNumber=scan.next();
								}
							}
							bean.setPhone(phoneNumber);
							System.out.println("Enter your address     :");
							String address=scan.next();
							while(true){
								if(hotelValid.validateAddress(address)){
									break;
								}else{
									System.err.println("Please enter address with more than 3 characters");
									address=scan.next();
								}
							}
							bean.setUserAddress(address);
							System.out.println("Enter your email id     :");
							String emailId=scan.next();
							while(true){
								if(hotelValid.validateEmailId(emailId)){
									break;
								}else{
									System.err.println("Please enter valid email Id(ex:admin@gmail.com)");
									emailId=scan.next();
								}
							}
							bean.setEmail(emailId);
							System.out.println("Create your password with minimum 2 and maximum 7 characters and no spaces:");
							String password=scan.next();
							while(true){
								if(hotelValid.validatePassword(password)){
									break;
								}else{
									System.err.println("Please enter password with minimum 2 and maximum 7 characters and no spaces");
									password=scan.next();
								}
							}
							bean.setPassword(password);
							String userId1=hotelService.registerHotelService(bean);
							System.out.println("Your userId is:"+userId1);
							System.out.println("Your password is:"+password);
							break;
						case "3":
							logger.info("EXIT");
							System.out.println("Thank You, Please visit Again...");
							System.exit(0);
							break;
						default:
							System.out.println("Enter Valid choice 1-3");
							break;
						}
					}while(choice!="3");
					break;
				case "2":
					do{
						System.out.println("____________ADMIN___________________\n");
						System.out.println("  1.Login");
						System.out.println("  2.Exit");
						choice=scan.next();
						switch(choice){
						case "1":
							System.out.println("Enter your admin id   :");
							String uname=scan.next();
							while(true){
								if(hotelValid.validateUserId(uname)){
									break;
								}else{
									System.err.println("Please enter numeric id");
									uname=scan.next();
								}
							}
							System.out.println("Enter password without any spaces");
							String pwd=scan.next();
							while(true){
								if(hotelValid.validatePassword(pwd)){
									break;
								}else{
									System.err.println("Please enter password with minimum 2 and maximum 7 characters and no spaces");
									pwd=scan.next();
								}
							}
							boolean login=hotelService.validateAdminDetails(uname, pwd);
							if(login==false){
								System.out.println("Invalid credentials");
							}
							else{
								System.out.println("WELCOME");
								do{
									System.out.println("_______________________________\n");
									System.out.println("OPERATIONS\n");
									System.out.println("_______________________________\n");
									System.out.println("  1.Hotel Management");
									System.out.println("  2.Room Management");
									System.out.println("  3.View Reports");
									System.out.println("  4.exit");
									choice=scan.next();
									switch(choice){
									case "1":
										do{
											System.out.println("--------Hotel Management--------");
											System.out.println("  1.Add Hotel");
											System.out.println("  2.Delete Hotel");
											System.out.println("  3.Update Hotel");
											System.out.println("  4.exit");
											choice=scan.next();
											switch(choice){
											case "1":
												logger.info("ADD HOTEL");
												System.out.println("Please Enter the Hotel details");
												System.out.println("Enter City    :");
												String city=scan.next();
												while(true){
													if(hotelValid.validateCity(city)){
														break;
													}else{
														System.err.println("Please enter city with more than 4 characters");
														city=scan.next();
													}
												}
												bean.setCity(city);
												System.out.println("Enter Hotel Name     :");
												String hotelName=scan.next();
												while(true){
													if(hotelValid.validateName(hotelName)){
														break;
													}else{
														System.err.println("Please enter city with more than 4 characters");
														hotelName=scan.next();
													}
												}
												bean.setHotelName(hotelName);
												System.out.println("Enter address    :");
												String hotelAddress=scan.next();
												while(true){
													if(hotelValid.validateAddress(hotelAddress)){
														break;
													}else{
														System.err.println("Please enter address with more than 4 characters");
														hotelAddress=scan.next();
													}
												}
												bean.setHotelAddress(hotelAddress);
												System.out.print("Enter Description     :");
												String description=scan.next();
												while(true){
													if(hotelValid.validateDescription(description)){
														break;
													}else{
														System.err.println("Please enter description with more than 4 characters");
														description=scan.next();
													}
												}
												bean.setDescription(description);
												System.out.println("Create average rate per night    :");
												int avgRatePerNight=Integer.parseInt(scan.next());

												bean.setAvgRatePerNight(avgRatePerNight);
												System.out.println("Enter your phone number 1     :");
												String phoneNo1=scan.next();
												while(true){
													if(hotelValid.validatePhoneNumber(phoneNo1)){
														break;
													}else{
														System.err.println("Please enter Phone number");
														phoneNo1=scan.next();
													}
												}
												bean.setPhoneNo1(phoneNo1);
												System.out.println("Enter your phone number 2    :");
												String phoneNo2=scan.next();
												while(true){
													if(hotelValid.validatePhoneNumber(phoneNo2)){
														break;
													}else{
														System.err.println("Please enter Phone number");
														phoneNo2=scan.next();
													}
												}
												bean.setPhoneNo2(phoneNo2);
												System.out.println("Enter Rating(GOOD,AVERAGE,POOR):");
												String rating=scan.next();
												while(true){
													if(hotelValid.validateRating(rating)){
														break;
													}else{
														System.err.println("Please enter valid rating");
														rating=scan.next();
													}
												}
												bean.setRating(rating);
												System.out.println("Enter Email Id                  :");
												String hotelEmail=scan.next();
												while(true){
													if(hotelValid.validateEmailId(hotelEmail)){
														break;
													}else{
														System.err.println("Please enter email Id");
														hotelEmail=scan.next();
													}
												}
												bean.setHotelEmail(hotelEmail);
												System.out.println("Enter Fax                   :");
												String fax=scan.next();
												while(true){
													if(hotelValid.validateFax(fax)){
														break;
													}else{
														System.err.println("Please enter Phone number");
														fax=scan.next();
													}
												}
												bean.setFax(fax);
												String hotel=hotelService.addHotel(bean);
												System.out.println(hotel);
												break;
											case "2":
												logger.info("DELETE HOTEL");
												System.out.println("Enter the hotel you want to delete:");
												String hotelId=scan.next();
												while(true){
													if(hotelValid.validateHotelId(hotelId)){
														break;
													}else{
														System.err.println("Please enter numeric id");
														hotelId=scan.next();
													}
												}
												boolean flag=hotelService.deleteHotel(hotelId);
												if(flag==true)
												{
													System.out.println("Succesfully deleted hotel with hotelId:"+hotelId);
												}
												else
												{
													logger.error("Enter valid hotelid");
													System.out.println("Please enter valid hotel id with maximum 4 digits");
												}
												break;
											case "3":
												logger.info("UPDATE HOTEL");
												System.out.println("Enter the Hotel you want to update:");
												String hotelId1=scan.next();
												while(true){
													if(hotelValid.validateHotelId(hotelId1)){
														break;
													}else{
														System.err.println("Please enter numeric id with maximum 4 digits");
														hotelId1=scan.next();
													}
												}
												System.out.println("Enter the Description you want to update:");
												String description1=scan.next();
												while(true){
													if(hotelValid.validateDescription(description1)){
														break;
													}else{
														System.err.println("Please enter address  with maximum 4 characters");
														description1=scan.next();
													}
												}
												boolean check=hotelService.updateHotel(hotelId1,description1);
												if(check==true)
												{
													System.out.println("Succesfully updated hotel with hotelId:"+hotelId1);
												}
												else
												{
													logger.error("Enter valid hotelid");
													System.out.println("Enter valid hotel Id with maximum 4 digits");
												}
												break;
											case "4":
												logger.info("EXIT");
												System.out.println("you are out of the application");
												System.exit(0);
												break;
											default :
												System.out.println("Please choose valid option 1-4");
												break;
											}
										}while(choice!="4");
										break;
									case "2":
										logger.info("MANAGING ROOM");
										do{
											System.out.println("--------Room Management--------");
											System.out.println("  1.Add Room");
											System.out.println("  2.Delete Room");
											System.out.println("  3.Update Room");
											System.out.println("  4.exit");
											choice=scan.next();
											switch(choice){
											case "1":
												logger.info("ADD ROOM");
												System.out.println("Please Enter the Room details");
												System.out.println("Enter Hotel Id    :");
												String hotelId=scan.next();
												while(true){
													if(hotelValid.validateHotelId(hotelId)){
														break;
													}else{
														System.err.println("Please enter numeric id with maximum 4 digits");
														hotelId=scan.next();
													}
												}
												bean.setHotelId(hotelId);
												System.out.println("Enter Room Id    :");
												String roomId=scan.next();
												while(true){
													if(hotelValid.validateRoomId(roomId)){
														break;
													}else{
														System.err.println("Please enter numeric id");
														roomId=scan.next();
													}
												}
												bean.setRoomId(roomId);
												System.out.println("Enter Room Type     :");
												String roomType=scan.next();
												while(true){
													if(hotelValid.validateRoomType(roomType)){
														break;
													}else{
														System.err.println("Please enter valid rating");
														roomType=scan.next();
													}
												}
												bean.setRoomType(roomType);
												System.out.println("Enter Room rate per night:");
												int ratePerNight=Integer.parseInt(scan.next());											
												bean.setRatePerNight(ratePerNight);
												boolean room=hotelService.addRoom(bean);
												if(room==true)
												{
													System.out.println("Room Id "+roomId+" successfully added in Hotel Id"+hotelId);		
												}
												else
												{
													logger.error("Enter valid details");
													System.out.println("please enter valid details");
												}
												break;
											case "2":
												logger.info("DELETE ROOM");
												System.out.println("Enter the hotel you want to delete a room:");
												String hotelId1=scan.next();
												while(true){
													if(hotelValid.validateHotelId(hotelId1)){
														break;
													}else{
														System.err.println("Please enter numeric id");
														hotelId1=scan.next();
													}
												}
												System.out.println("Enter the Room you want to delete:");
												String roomId1=scan.next();
												while(true){
													if(hotelValid.validateRoomId(roomId1)){
														break;
													}else{
														System.err.println("Please enter numeric id");
														roomId1=scan.next();
													}
												}
												boolean flag=hotelService.deleteRoom(hotelId1,roomId1);
												if(flag==true)
												{
													System.out.println("Succesfully deleted Room with " +roomId1+" in hotel "+hotelId1);
												}
												else
												{
													logger.error("Enter valid room id");
													System.out.println("Please enter valid room id");
												}
												break;
											case "3":
												logger.info("UPDATE ROOM");
												System.out.println("Enter the Hotel you want to update:");
												String hotelId2=scan.next();
												while(true){
													if(hotelValid.validateHotelId(hotelId2)){
														break;
													}else{
														System.err.println("Please enter numeric id with maximum 4 digits");
														hotelId2=scan.next();
													}
												}
												System.out.println("Enter the Room you want to update:");
												String room1=scan.next();
												while(true){
													if(hotelValid.validateRoomId(room1)){
														break;
													}else{
														System.err.println("Please enter numeric id with maximum 4 digits");
														room1=scan.next();
													}
												}
												System.out.println("Enter the tariff you want to update:");
												String tariff=scan.next();
												boolean check=hotelService.updateRoom(hotelId2,room1,tariff);
												if(check==true)
												{
													System.out.println("Succesfully updated room:"+room1+" in hotel:"+hotelId2+" with new tariff "+tariff);
												}
												else
												{
													logger.error("Enter valid hotel id");
													System.out.println("Enter valid hotel Id with maximum 4 digits");
												}
												break;
											case "4":
												logger.info("EXIT");
												System.out.println("you are out of the application");
												System.exit(0);
												break;
											default :
												System.out.println("Please choose valid option 1-4");
												break;
											}
										}while(choice!="4");
										break;
									case "3":
										logger.info("VIEW REPORTS");
										do{
											System.out.println("--------View Reports--------");
											System.out.println("  1.List of Hotels");
											System.out.println("  2.Bookings of Specific Hotel");
											System.out.println("  3.guest list of Specific Hotel");
											System.out.println("  4.Bookings for Specified Date");
											System.out.println("  5.exit");
											choice=scan.next();
											switch(choice){
											case "1":
												logger.info("LIST OF HOTELS");
												System.out.println("List of Hotels");
												ArrayList<HotelBean> hotel=hotelService.hotelList();
												for (HotelBean hotelBean : hotel) {
													System.out.println(" "+hotelBean.getHotelId()+"  "+hotelBean.getHotelName());
												}
												break;
											case "2":
												logger.info("HOTEL BOOKINGS");
												System.out.println("Bookings of Specific Hotel");
												System.out.println("Enter hotel id ");
												String hotel2=scan.next();
												while(true){
													if(hotelValid.validateHotelId(hotel2)){
														break;
													}else{
														System.err.println("Please enter numeric id with maximum 4 digits");
														hotel2=scan.next();
													}
												}
												ArrayList<HotelBean> hotel1=hotelService.hotelBookings(hotel2);
												for (HotelBean hotelBean : hotel1) {
													System.out.println(" "+hotelBean.getBookingId()+"  "+hotelBean.getRoomId()+" "+hotelBean.getUserId()+"  "+hotelBean.getBookedFrom()+" "+hotelBean.getBookedTo()+"  "+hotelBean.getNoOfAdults()+" "+hotelBean.getNoOfChildern()+"  "+hotelBean.getAmount());
												}
												break;
											case "3":
												logger.info("LIST OF SPECIFIC HOTELS");
												System.out.println("Guest List of Specific Hotel");
												System.out.println("Enter hotel id ");
												String hotel3=scan.next();
												while(true){
													if(hotelValid.validateHotelId(hotel3)){
														break;
													}else{
														System.err.println("Please enter numeric id with maximum 4 digits");
														hotel3=scan.next();
													}
												}
												ArrayList<HotelBean> guestList=hotelService.hotelGuestList(hotel3);
												for (HotelBean hotelBean : guestList) {
													System.out.println(" "+hotelBean.getUserId()+"  "+hotelBean.getUserName()+" "+hotelBean.getMobileNo()+"  "+hotelBean.getBookedFrom()+" "+hotelBean.getBookedTo());
												}
												break;
											case "4":
												logger.info("BOOKINGS ON SPECIFIC DATE");
												System.out.println("Bookings of Specific Date");
												System.out.println("Enter Date (dd-mmm-yyyy)");
												String date=scan.next();
												ArrayList<HotelBean> bookingList=hotelService.hotelDateBooking(date);
												for (HotelBean hotelBean : bookingList) {
													System.out.println(hotelBean.getHotelId()+" "+hotelBean.getUserId()+"  "+hotelBean.getUserName()+" "+hotelBean.getMobileNo()+"  "+hotelBean.getBookedFrom()+" "+hotelBean.getBookedTo());
												}
												break;
											case "5":
												logger.info("OUT OF APPLICATION");
												System.out.println("you are out of the application");
												System.exit(0);
												break;
											default :
												System.out.println("Please choose valid option 1-5");
												break;
											}
										}while(choice!="5");
										break;
									case "4":
										logger.info("OUT OF APPLICATION");
										System.out.println("you are out of the application");
										System.exit(0);
										break;
									default:
										System.out.println("Please choose valid option 1-4");
										break;
									}
								}while(choice!="4");
								break;
							}break;
						case "2":
							logger.info("OUT OF APPLICATION");
							System.out.println("you are out of the application");
							System.exit(0);
							break;
						default :
							System.out.println("Please choose valid option 1-2");
							break;
						}
					}while(choice!="2");
					break;
				case "3":
					logger.info("OUT OF APPLICATION");
					System.out.println("you are out of the application");
					System.exit(0);
					break;
				default :
					System.out.println("Please choose valid option 1-3");
					break;
				}
			}while(choice!="3");

		} catch (HotelException e) {

			System.out.println(e.getMessage());

		}


	}

}		