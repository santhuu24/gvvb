package com.cg.bean;

import java.sql.Date;



public class HotelBean {
	//Users table
	private String userId;
	private String password;
	private String role;
	private String userName;
	private String mobileNo;
	private String phone;
	private String userAddress;
	private String email;

	//Hotel table
	private String hotelId;
	private String city;
	private String hotelName;
	private String hotelAddress;
	private String description;
	private int avgRatePerNight;
	private String phoneNo1;
	private String phoneNo2;
	private String rating;
	private String hotelEmail;
	private String fax;

	//RoomDetails table
	private String roomId;
	private String roomNo;
	private String roomType;
	private int ratePerNight;
	private String availability;


	//Booking Details table
	private String bookingId;
	private Date bookedFrom;
	private Date bookedTo;
	private String noOfAdults;
	private String noOfChildern;
	private float amount;
	@Override
	public String toString() {
		return "HotelBean [userId=" + userId + ", password=" + password
				+ ", role=" + role + ", userName=" + userName
				+ ", mobileNo=" + mobileNo + ", phone=" + phone
				+ ", userAddress=" + userAddress + ", email=" + email
				+ ", hotelId=" + hotelId + ", city=" + city
				+ ", hotelName=" + hotelName + ", hotelAddress="
				+ hotelAddress + ", description=" + description
				+ ", avgRatePerNight=" + avgRatePerNight + ", phoneNo1="
				+ phoneNo1 + ", phoneNo2=" + phoneNo2 + ", rating="
				+ rating + ", hotelEmail=" + hotelEmail + ", fax=" + fax
				+ ", roomId=" + roomId + ", roomNo=" + roomNo
				+ ", roomType=" + roomType + ", ratePerNight="
				+ ratePerNight + ", availability=" + availability
				+ ", bookingId=" + bookingId + ", bookedFrom=" + bookedFrom
				+ ", bookedTo=" + bookedTo + ", noOfAdults=" + noOfAdults
				+ ", noOfChildern=" + noOfChildern + ", amount=" + amount
				+ "]";
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getHotelAddress() {
		return hotelAddress;
	}
	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getAvgRatePerNight() {
		return avgRatePerNight;
	}
	public void setAvgRatePerNight(int avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}
	public String getPhoneNo1() {
		return phoneNo1;
	}
	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}
	public String getPhoneNo2() {
		return phoneNo2;
	}
	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getHotelEmail() {
		return hotelEmail;
	}
	public void setHotelEmail(String hotelEmail) {
		this.hotelEmail = hotelEmail;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getRoomId() {
		return roomId;
	}
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public int getRatePerNight() {
		return ratePerNight;
	}
	public void setRatePerNight(int ratePerNight) {
		this.ratePerNight = ratePerNight;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability2) {
		this.availability = availability2;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public Date getBookedFrom() {
		return bookedFrom;
	}
	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}
	public Date getBookedTo() {
		return bookedTo;
	}
	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}
	
	public String getNoOfAdults() {
		return noOfAdults;
	}
	public void setNoOfAdults(String noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	public String getNoOfChildern() {
		return noOfChildern;
	}
	public void setNoOfChildern(String noOfChildern) {
		this.noOfChildern = noOfChildern;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}


}
