package com.cg.dao;

public interface QueryMapper {
	public static final String INSERT_USERS_QUERY="INSERT INTO users values(user_id.nextval,?,'user',?,?,?,?,?)";
	public static final String RETRIEVE_USER_QUERY="SELECT user_id ,password FROM users WHERE role='user' AND user_id=? AND password=?";
	public static final String RETRIEVE_USER_SEQ="SELECT user_id.currval FROM DUAL";
	public static final String RETRIEVE_ADMIN_QUERY="SELECT user_id ,password FROM users WHERE role='admin' AND user_id=? AND password=?";
	public static final String INSERT_HOTEL_QUERY="INSERT INTO hotel values(hotel_id.nextval,?,?,?,?,?,?,?,?,?,?)";
	public static final String RETRIEVE_HOTEL_SEQ="SELECT hotel_id.currval FROM DUAL";
	
	public static final String DELETE_HOTEL="DELETE FROM hotel WHERE hotel_id=?";
	public static final String UPDATE_HOTEL="UPDATE hotel set description=? WHERE hotel_id=?";
	public static final String INSERT_ROOM_QUERY="INSERT INTO roomdetails values(?,?,?,?,'true')";
	public static final String DELETE_ROOM="DELETE FROM roomdetails WHERE hotel_id=? AND room_id=?";
	public static final String UPDATE_ROOM="UPDATE roomdetails SET per_night_rate=? where hotel_id=? and room_id=?";
	public static final String HOTEL_LIST="SELECT hotel_id,hotel_name FROM hotel ORDER BY hotel_id";
	public static final String BOOKING_HOTEL="SELECT booking_id,room_id,user_id,booked_from,booked_to,no_of_adults,no_of_children,amount FROM bookingdetails WHERE hotel_id=?";
	public static final String GUEST_LIST="select b.user_id,u.user_name,u.mobile_no,b.booked_from,b.booked_to from bookingdetails b join users u on b.user_id=u.user_id where hotel_id=?";
	public static final String BOOKING_DATE="select b.hotel_id,b.user_id,u.user_name,u.mobile_no,b.booked_from,b.booked_to from bookingdetails b join users u on b.user_id=u.user_id where ? between b.booked_from and b.booked_to";
	public static final String AVAILABLE_ROOMS1="select h.hotel_id,h.hotel_name,r.room_id,r.room_type,r.per_night_rate,h.city,h.address,h.description,h.phone_no1,h.phone_no2,h.rating,h.email,h.fax from hotel h join roomdetails r on h.hotel_id=r.hotel_id join bookingdetails b on r.room_id=b.room_id where ((?<b.booked_from and ?<b.booked_from) or (?>b.booked_to and ?>b.booked_to))";
	public static final String AVAILABLE_ROOMS2="select h.hotel_id,h.hotel_name,r.room_id,r.room_type,r.per_night_rate,h.city,h.address,h.description,h.phone_no1,h.phone_no2,h.rating,h.email,h.fax from hotel h join roomdetails r on h.hotel_id=r.hotel_id  where r.availability='true'";
	public static final String BOOK_ROOM="INSERT INTO  bookingdetails values(booking_seq.nextval,?,?,?,?,?,?,?,?)";
	public static final String GET_ROOM_AMOUNT="SELECT per_night_rate FROM roomdetails where room_Id=? and hotel_id=?";
	public static final String RETRIEVE_BOOKING_SEQ="SELECT booking_seq.currval FROM DUAL";
	public static final String CHANGE_AVAILABILITY="UPDATE roomdetails set availability='false' WHERE hotel_Id=? and room_Id=?";
	public static final String VIEW_STATUS="SELECT * FROM bookingdetails where booking_id=?";
}
