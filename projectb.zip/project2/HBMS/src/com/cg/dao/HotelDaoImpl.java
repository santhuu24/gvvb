package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.bean.HotelBean;
import com.cg.exception.HotelException;
import com.cg.util.DBConnection;

public class HotelDaoImpl implements IHotelDAO {
	Connection con;
	String user_id;
	String hotel;
	String room;



	@Override
	public String registerHotelDao(HotelBean bean) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		PreparedStatement statement1=null;

		try {
			statement=con.prepareStatement(QueryMapper.INSERT_USERS_QUERY);
			statement.setString(1,bean.getPassword());
			statement.setString(2,bean.getUserName());
			statement.setString(3, bean.getMobileNo());
			statement.setString(4, bean.getPhone());
			statement.setString(5, bean.getUserAddress());
			statement.setString(6, bean.getEmail());
			ResultSet res=statement.executeQuery();
			statement1=con.prepareStatement(QueryMapper.RETRIEVE_USER_SEQ);
			res=statement1.executeQuery();
			res.next();
			user_id=res.getString(1);

		} catch (SQLException e) {
			

			throw new HotelException("Error in registering usser");
		}
		finally{
			try {
				statement.close();
				statement1.close();
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in registerHotelDao");
			}


		}




		return user_id;
	}



	@Override
	public boolean loginUserDetails(String userid,String password) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;

		boolean check=false;
		try {
			statement=con.prepareStatement(QueryMapper.RETRIEVE_USER_QUERY);
			statement.setString(1,userid);
			statement.setString(2, password);
			ResultSet res=statement.executeQuery();
			if(res.next()){

				check=true;

			}



		} catch (SQLException e) {

			throw new HotelException("Error in login page. Please enter valid details");


		}
		finally{
			try {
				statement.close();
				con.close();
			} catch (SQLException e) {

				
				throw new HotelException("Error in closing connections in loginuserdetails");
			}



		}
		return check;

	}




	@Override
	public boolean loginAdminDetails(String userid, String password) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;

		boolean check=false;
		try {
			statement=con.prepareStatement(QueryMapper.RETRIEVE_ADMIN_QUERY);
			statement.setString(1,userid);
			statement.setString(2,password);
			ResultSet res1=statement.executeQuery();
			if(res1.next()){

				check=true;

			}



		} catch (SQLException e) {

			throw new HotelException("Error in login page. Please enter valid details");


		}
		finally{

			try {
				statement.close();
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in loginadmindetails");
			}
		}
		return check;

	}




	@Override
	public String addHotelDao(HotelBean bean) throws HotelException{
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		PreparedStatement statement1=null;

		try{
			statement=con.prepareStatement(QueryMapper.INSERT_HOTEL_QUERY);
			statement.setString(1,bean.getCity());
			statement.setString(2,bean.getHotelName());
			statement.setString(3,bean.getHotelAddress());
			statement.setString(4,bean.getDescription());
			statement.setInt(5,bean.getAvgRatePerNight());
			statement.setString(6,bean.getPhoneNo1());
			statement.setString(7,bean.getPhoneNo2());
			statement.setString(8,bean.getRating());
			statement.setString(9,bean.getHotelEmail());
			statement.setString(10,bean.getFax());
			ResultSet res=statement.executeQuery();
			statement1=con.prepareStatement(QueryMapper.RETRIEVE_HOTEL_SEQ);
			res=statement1.executeQuery();
			res.next();
			hotel=res.getString(1);

		} catch (SQLException e) {

			throw new HotelException("Error in adding hotels into hotel database");
		}
		finally{

			try {
				statement.close();
				statement1.close();
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Error in closing connections in addHotelDao");
			}



		}

		return hotel;
	}




	@Override
	public boolean deleteHotelDao(String hotelId) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;

		boolean check=false;
		try{
			statement=con.prepareStatement(QueryMapper.DELETE_HOTEL);
			
			statement.setString(1,hotelId);
			ResultSet res1=statement.executeQuery();
			


			if(res1.next()){

				check=true;

			}
		}

		catch (SQLException e) {

			throw new HotelException("Error in deleting hotel from hotel database. Please enter valid details");


		}
		finally{

			try {
				statement.close();

				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in deleteHotelDao");
			}



		}
		return check;
	}




	@Override
	public boolean updateHotelDao(String hotelId1, String description1) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		boolean check=false;
		try{
			statement=con.prepareStatement(QueryMapper.UPDATE_HOTEL);
			statement.setString(1, description1);
			statement.setString(2,hotelId1);
			ResultSet res1=statement.executeQuery();
			if(res1.next()){

				check=true;

			}
		}

		catch (SQLException e) {

			throw new HotelException("Error in updataing the hotel details in hotel database. Please enter valid details");


		}
		finally{

			try {
				statement.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in UpdateHotelDao");
			}



		}
		return check;
	}



	@Override
	public boolean addRoomDao(HotelBean bean) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		try{
			statement=con.prepareStatement(QueryMapper.INSERT_ROOM_QUERY);
			statement.setString(1,bean.getHotelId());
			statement.setString(2,bean.getRoomId());
			statement.setString(3,bean.getRoomType());
			statement.setInt(4,bean.getRatePerNight());
			ResultSet res=statement.executeQuery();
			res.next();

		} catch (SQLException e) {

			throw new HotelException("Error in adding room details to room database");
		}
		
		finally{

			try {
				statement.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in addRoomDao");
			}



		}

		return true;
	}



	@Override
	public boolean deleteRoomDao(String hotelId1, String roomId1) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		boolean check=false;
		try{
			statement=con.prepareStatement(QueryMapper.DELETE_ROOM);
			statement.setString(1,hotelId1);
			statement.setString(2, roomId1);
			ResultSet res1=statement.executeQuery();
			if(res1.next()){

				check=true;

			}
		}

		catch (SQLException e) {


			throw new HotelException("Error in deleting room details from room database Please enter valid details");

		}
		finally{

			try {
				statement.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in deleteRoomDao");
			}



		}
		return check;
	}



	@Override
	public boolean updateRoomDao(String hotelId1, String room1, String tariff) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		boolean check=false;
		try{
			statement=con.prepareStatement(QueryMapper.UPDATE_ROOM);
			statement.setString(1,tariff);
			statement.setString(2, hotelId1);
			statement.setString(3,room1);
			ResultSet res1=statement.executeQuery();
			if(res1.next()){

				check=true;

			}
		}

		catch (SQLException e) {

			throw new HotelException("Error in updating room details. Please enter valid details");


		}
		finally{

			try {
				statement.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in updateRoomDao");
			}



		}
		return check;
	}




	@Override
	public ArrayList<HotelBean> hotelListDao() throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		ArrayList<HotelBean> hotelList=new ArrayList<HotelBean>();
		try{
			statement=con.prepareStatement(QueryMapper.HOTEL_LIST);

			ResultSet res1=statement.executeQuery();
			while(res1.next()){
				HotelBean bean=new HotelBean();
				bean.setHotelId(res1.getString(1));
				bean.setHotelName(res1.getString(2));
				hotelList.add(bean);

			}
		}

		catch (SQLException e) {

			throw new HotelException("Error in displaying hotel list. Please enter valid details");


		}
		finally{

			try {
				statement.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in hotelListDao");
			}



		}
		return hotelList;
	}




	@Override
	public ArrayList<HotelBean> hotelBookingDao(String hotel) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		ArrayList<HotelBean> hotelList=new ArrayList<HotelBean>();
		try{
			statement=con.prepareStatement(QueryMapper.BOOKING_HOTEL);
			statement.setString(1, hotel);
			ResultSet res1=statement.executeQuery();
			while(res1.next()){
				HotelBean bean=new HotelBean();
				bean.setBookingId(res1.getString(1));
				bean.setRoomId(res1.getString(2));
				bean.setUserId(res1.getString(3));
				bean.setBookedFrom(res1.getDate(4));
				bean.setBookedTo(res1.getDate(5));
				bean.setNoOfAdults(res1.getString(6));
				bean.setNoOfChildern(res1.getString(7));
				bean.setAmount(res1.getFloat(8));
				hotelList.add(bean);

			}
		}

		catch (SQLException e) {

			throw new HotelException("Error in booking hotel room. Please enter valid details");


		}
		finally{

			try {
				statement.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in hotelBookingDao");
			}



		}
		return hotelList;
	}



	@Override
	public ArrayList<HotelBean> hotelGuestList(String hotel3) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		ArrayList<HotelBean> hotelList=new ArrayList<HotelBean>();
		try{
			statement=con.prepareStatement(QueryMapper.GUEST_LIST);
			statement.setString(1, hotel3);
			ResultSet res1=statement.executeQuery();
			while(res1.next()){
				HotelBean bean=new HotelBean();
				bean.setUserId(res1.getString(1));
				bean.setUserName(res1.getString(2));
				bean.setMobileNo(res1.getString(3));
				bean.setBookedFrom(res1.getDate(4));
				bean.setBookedTo(res1.getDate(5));
				hotelList.add(bean);

			}
		}

		catch (SQLException e) {

			throw new HotelException("Error in displaying guest list. Please enter valid details");


		}
		finally{

			try {
				statement.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in hotelGuestList");
			}



		}
		return hotelList;
	}
	@Override
	public ArrayList<HotelBean> hotelBookingDate(String hotel4) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		ArrayList<HotelBean> hotelList=new ArrayList<HotelBean>();
		try{
			statement=con.prepareStatement(QueryMapper.BOOKING_DATE);
			statement.setString(1, hotel4);
			ResultSet res1=statement.executeQuery();
			while(res1.next()){
				HotelBean bean=new HotelBean();
				bean.setHotelId(res1.getString(1));
				bean.setUserId(res1.getString(2));
				bean.setUserName(res1.getString(3));
				bean.setMobileNo(res1.getString(4));
				bean.setBookedFrom(res1.getDate(5));
				bean.setBookedTo(res1.getDate(6));
				hotelList.add(bean);

			}
		}

		catch (SQLException e) {

			throw new HotelException("Please enter valid details");


		}
		finally{

			try {
				statement.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in hotelBookingDate");
			}



		}
		return hotelList;
	}
	@Override
	public ArrayList<HotelBean> searchRoomDao(Date fromDate,Date toDate) throws HotelException {
		con=DBConnection.ConnectToDB();
		ArrayList<HotelBean> hotelList=new ArrayList<HotelBean>();
		PreparedStatement statement=null;
		PreparedStatement statement1=null;
		try{
			statement=con.prepareStatement(QueryMapper.AVAILABLE_ROOMS1);
			statement.setDate(1, fromDate);
			statement.setDate(2, toDate);
			statement.setDate(3, fromDate);
			statement.setDate(4, toDate);
			ResultSet res1=statement.executeQuery();
			while(res1.next()){
				HotelBean bean=new HotelBean();
				bean.setHotelId(res1.getString(1));
				bean.setHotelName(res1.getString(2));
				bean.setRoomId(res1.getString(3));
				bean.setRoomType(res1.getString(4));
				bean.setRatePerNight(res1.getInt(5));
				bean.setCity(res1.getString(6));
				bean.setHotelAddress(res1.getString(7));
				bean.setDescription(res1.getString(8));
				bean.setPhoneNo1(res1.getString(9));
				bean.setPhoneNo2(res1.getString(10));
				bean.setRating(res1.getString(11));
				bean.setEmail(res1.getString(12));
				bean.setFax(res1.getString(13));
				hotelList.add(bean);


			}
			statement1=con.prepareStatement(QueryMapper.AVAILABLE_ROOMS2);
			ResultSet res2=statement1.executeQuery();
			while(res2.next()){
				HotelBean bean1=new HotelBean();
				bean1.setHotelId(res2.getString(1));
				bean1.setHotelName(res2.getString(2));
				bean1.setRoomId(res2.getString(3));
				bean1.setRoomType(res2.getString(4));
				bean1.setRatePerNight(res2.getInt(5));
				bean1.setCity(res2.getString(6));
				bean1.setHotelAddress(res2.getString(7));
				bean1.setDescription(res2.getString(8));
				bean1.setPhoneNo1(res2.getString(9));
				bean1.setPhoneNo2(res2.getString(10));
				bean1.setRating(res2.getString(11));
				bean1.setEmail(res2.getString(12));
				bean1.setFax(res2.getString(13));
				hotelList.add(bean1);


			}
		}

		catch (SQLException e) {

			throw new HotelException("Error in seraching rooms. Please enter valid details");


		}
		finally{

			try {
				statement.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in SearchRoomDao");
			}



		}
		return hotelList;
	}


	@Override
	public String bookRoom(HotelBean bean) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		PreparedStatement statement1=null;
		String	bookingId = null;
		try {
			statement=con.prepareStatement(QueryMapper.BOOK_ROOM);
			statement.setString(1,bean.getHotelId());
			statement.setString(2,bean.getRoomId());
			statement.setString(3,bean.getUserId());
			statement.setDate(4, bean.getBookedFrom());
			statement.setDate(5,bean.getBookedTo());
			statement.setString(6,bean.getNoOfChildern());
			statement.setString(7,bean.getNoOfAdults());
			statement.setFloat(8,bean.getAmount());
			statement.executeUpdate();

			statement1=con.prepareStatement(QueryMapper.RETRIEVE_BOOKING_SEQ);
			ResultSet res=statement1.executeQuery();
			res.next();
			bookingId=res.getString(1);


		} catch (SQLException e) {
			
			throw new HotelException("Error in booking room. Please provide valid details");
		}
		finally{

			try {
				statement.close();
				statement1.close();
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in BookRoom");
			}



		}

		return bookingId;
	}





	@Override
	public float getAmountByRoom(String roomId, String hotelId) throws HotelException {

		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		float amount;
		try{
			statement=con.prepareStatement(QueryMapper.GET_ROOM_AMOUNT);
			statement.setString(1, roomId);
			statement.setString(2, hotelId);
			ResultSet res=statement.executeQuery();
			res.next();
			amount=Float.parseFloat(res.getString(1));
		}
		catch(SQLException e){
			throw new HotelException("Error in getting amount");
		}
		finally{

			try {
				statement.close();
				
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in getAmountByRoom");
			}



		}

		return amount;
	}


	@Override
	public Boolean changeAvailablity(String hotelId, String roomId) throws HotelException {
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;

		try{
			statement=con.prepareStatement(QueryMapper.CHANGE_AVAILABILITY);
			statement.setString(1, hotelId);
			statement.setString(2, roomId);
			/*int res=*/statement.executeUpdate();
		}catch(SQLException e){
			throw new HotelException("Error in changing the details");
		}
		finally{

			try {
				statement.close();
				
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in changeAvailability");
			}



		}
		return null;
	}


	@Override
	public HotelBean viewStatus(String bookingId) throws HotelException{
		con=DBConnection.ConnectToDB();
		PreparedStatement statement=null;
		HotelBean bean=new HotelBean();
		try{
			statement=con.prepareStatement(QueryMapper.VIEW_STATUS);
			statement.setString(1, bookingId);

			/*HotelServiceImpl h=new HotelServiceImpl();*/

			ResultSet res1=statement.executeQuery();

			res1.next();
			bean.setBookingId(res1.getString(1));
			bean.setHotelId(res1.getString(2));
			bean.setRoomId(res1.getString(3));
			bean.setUserId(res1.getString(4));
			bean.setBookedFrom(res1.getDate(5));
			bean.setBookedTo(res1.getDate(6));
			bean.setNoOfAdults(res1.getString(7));
			bean.setNoOfChildern(res1.getString(8));
			bean.setAmount(res1.getFloat(9));

		}
		catch(Exception e){

			throw new HotelException("Please enter valid details");
		}
		finally{

			try {
				statement.close();
				
				
				con.close();
			} catch (SQLException e) {
				
				throw new HotelException("Error in closing connections in viewStatus");
			}



		}
		return bean;
	}




}
