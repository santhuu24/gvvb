package com.cg.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.bean.HotelBean;
import com.cg.exception.HotelException;

public interface IHotelDAO {
	public String registerHotelDao(HotelBean bean) throws HotelException, SQLException;
	
	public boolean loginUserDetails(String userid, String pwd) throws HotelException;
	public boolean loginAdminDetails(String userid, String pwd) throws HotelException;
	public String addHotelDao(HotelBean bean) throws HotelException;

	public boolean deleteHotelDao(String hotelId) throws HotelException;

	

	public boolean updateHotelDao(String hotelId1, String description1) throws HotelException;

	public boolean addRoomDao(HotelBean bean) throws HotelException;

	public boolean deleteRoomDao(String hotelId1, String roomId1) throws HotelException;

	public boolean updateRoomDao(String hotelId1, String room1, String tariff) throws HotelException;

	public  ArrayList<HotelBean> hotelListDao() throws HotelException;

	public ArrayList<HotelBean> hotelBookingDao(String hotel) throws HotelException;

	public ArrayList<HotelBean> hotelGuestList(String hotel3) throws HotelException;

	public ArrayList<HotelBean> hotelBookingDate(String hotel4) throws HotelException;

	public ArrayList<HotelBean> searchRoomDao(Date fromDate,Date toDate) throws HotelException;
	public String bookRoom(HotelBean bean) throws HotelException;

	public float getAmountByRoom(String roomId, String hotelId) throws HotelException;

	public Boolean changeAvailablity(String hotelId, String roomId) throws HotelException;

	public HotelBean viewStatus(String bookingId) throws HotelException;
}
