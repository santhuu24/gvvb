package com.cg.service;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.bean.HotelBean;
import com.cg.exception.HotelException;

public interface IHotelService {
	
	public String registerHotelService(HotelBean bean) throws HotelException;
	public boolean validateUserDetails(String userid, String pwd) throws HotelException;
	public boolean validateAdminDetails(String userid, String pwd) throws HotelException;
	public String addHotel(HotelBean bean) throws HotelException;
	public boolean deleteHotel(String hotelId) throws HotelException;
	public boolean updateHotel(String hotelId1, String description1) throws HotelException;
	public boolean addRoom(HotelBean bean) throws HotelException;
	public boolean deleteRoom(String hotelId1, String roomId1) throws HotelException;
	public boolean updateRoom(String hotelId1, String room1, String tariff) throws HotelException;
	public ArrayList<HotelBean> hotelList() throws HotelException;
	public ArrayList<HotelBean> hotelBookings(String hotel) throws HotelException;
	public ArrayList<HotelBean> hotelGuestList(String hotel3) throws HotelException;
	public ArrayList<HotelBean> hotelDateBooking(String hotel4) throws HotelException;
	public ArrayList<HotelBean> searchRooms(Date fromDate,Date toDate) throws HotelException;
	public String bookRoom(HotelBean bean) throws HotelException;
	public float calculateAmount(Date from,Date to,float amount) throws HotelException;
	public float getAmountByRoom(String roomId,String hotelId) throws HotelException;
	public Date getSqlDate(String date) throws HotelException;
	public Boolean changeAvailability(String hotelId, String roomId) throws HotelException;
	public HotelBean viewStatus(String bookingId) throws HotelException;
}
