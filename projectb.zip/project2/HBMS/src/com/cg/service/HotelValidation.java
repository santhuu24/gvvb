package com.cg.service;

import java.sql.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HotelValidation {
	public boolean validateUserId(String userId){
		Pattern idPattern=Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher=idPattern.matcher(userId);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateHotelId(String hotelId) {
		Pattern idPattern=Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher=idPattern.matcher(hotelId);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateRoomId(String roomId) {
		Pattern idPattern=Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher=idPattern.matcher(roomId);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}



	public boolean validateNoOfChildren(String noOfChildren) {
		Pattern idPattern=Pattern.compile("[0-9]{1,2}");
		Matcher idMatcher=idPattern.matcher(noOfChildren);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateNoOfAdults(String noOfAdults) {
		Pattern idPattern=Pattern.compile("[0-9]{1,2}");
		Matcher idMatcher=idPattern.matcher(noOfAdults);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateBookingId(String bookingId) {
		Pattern idPattern=Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher=idPattern.matcher(bookingId);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateName(String name) {
		Pattern idPattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher idMatcher=idPattern.matcher(name);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateMobileNumber(String mobileNumber) {
		Pattern idPattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher idMatcher=idPattern.matcher(mobileNumber);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validatePhoneNumber(String phoneNumber) {
		Pattern idPattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher idMatcher=idPattern.matcher(phoneNumber);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateAddress(String address) {
		if(address.length()>3)
			return true;
		else
			return false;
	}

	public boolean validateEmailId(String emailId) {
		Pattern idPattern=Pattern.compile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$");
		Matcher idMatcher=idPattern.matcher(emailId);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validatePassword(String password) {
		Pattern idPattern=Pattern.compile("[a-zA-Z0-9]{2,7}");
		Matcher idMatcher=idPattern.matcher(password);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateCity(String city) {
		if(city.length()>3)
			return true;
		else
			return false;
	}

	public boolean validateDescription(String description) {
		if(description.length()>3)
			return true;
		else
			return false;
	}

	public boolean validateRating(String rating) {
		Pattern idPattern=Pattern.compile("GOOD|POOR|AVERAGE|good|poor|average|Good|Poor|Average");
		Matcher idMatcher=idPattern.matcher(rating);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateFax(String fax) {
		Pattern idPattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher idMatcher=idPattern.matcher(fax);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

	public boolean validateRoomType(String roomType) {
		Pattern idPattern=Pattern.compile("ac|nonac|AC|NONAC");
		Matcher idMatcher=idPattern.matcher(roomType);
		if(idMatcher.matches())
			return true;
		else
			return false;
	}
	public Boolean validateBookedFrom(Date booked) {
		
		Date d=new Date(System.currentTimeMillis());
		 Date date=booked;
		
		if(d.compareTo(date)<0){
			return true;
		}
		else
			 return false;
		
	}
}
