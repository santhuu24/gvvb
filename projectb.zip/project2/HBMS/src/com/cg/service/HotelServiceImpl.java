package com.cg.service;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import com.cg.bean.HotelBean;
import com.cg.dao.HotelDaoImpl;
import com.cg.dao.IHotelDAO;
import com.cg.exception.HotelException;

public class HotelServiceImpl implements IHotelService{

	IHotelDAO dao;

	public HotelServiceImpl() throws HotelException {
		dao=new HotelDaoImpl();
	}
	@Override
	public String registerHotelService(HotelBean bean) throws HotelException {
		String userId=null ;
		try{
			userId=dao.registerHotelDao(bean);

		}catch(Exception e){
			System.out.println(e.getMessage());
			throw new HotelException("Error in registering user. Please provide valid details");
		}
		return userId;

	}

	@Override
	public boolean validateUserDetails(String userid, String pwd) throws HotelException  {
		boolean password;
		try{
			password=dao.loginUserDetails(userid,pwd);
		}catch(Exception e){
			throw new HotelException("Username or password wrong. Please provide valid details");
		}
		return password;

	}
	@Override
	public boolean validateAdminDetails(String userid, String pwd) throws HotelException  {
		boolean password;
		try{
		password=dao.loginAdminDetails(userid,pwd);
		}catch(Exception e){
			throw new HotelException("User name or password wrong. Please provide valid details");
		}
		return password;
	}
	@Override
	public String addHotel(HotelBean bean) throws HotelException {
		String hotel;
		try{
		hotel=dao.addHotelDao(bean);
		}catch(Exception e){
			throw new HotelException("Error in adding hotel to hotel database");
		}
		return hotel;
	}
	@Override
	public boolean deleteHotel(String hotelId) throws HotelException {
		boolean flag;
		try{
		flag=dao.deleteHotelDao(hotelId);
		}catch(HotelException e){
			throw new HotelException("Error in deleting the hotel. Please provide valid details");
		}
		return flag;
	}

	@Override
	public boolean updateHotel(String hotelId1, String description1) throws HotelException {
		boolean check;
		try{
		check=dao.updateHotelDao(hotelId1,description1);
		}catch(HotelException e){
			throw new HotelException("Error in updating the hotel. Please provide the valid details");
		}
		return check;
	}
	@Override
	public boolean addRoom(HotelBean bean) throws HotelException {
		boolean room;
		try {
			room=dao.addRoomDao(bean);
		} catch (HotelException e) {
			throw new HotelException("Error in adding room");
		}return room;
	}
	@Override
	public boolean deleteRoom(String hotelId1, String roomId1) throws HotelException {
		boolean flag;
		try{
		flag=dao.deleteRoomDao(hotelId1,roomId1);
		}catch(HotelException e){
			throw new HotelException("Error in deleting the room from database. Please provide valid room Id");
		}
		return flag;
	}
	@Override
	public boolean updateRoom(String hotelId1, String room1, String tariff) throws HotelException {
		boolean check;
		try{
		check=dao.updateRoomDao(hotelId1,room1,tariff);
		}catch(HotelException e){
			throw new HotelException("Error in updating the room details. Please provide valid room id");
		}
		
		return check;
	}
	@Override
	public ArrayList<HotelBean> hotelList() throws HotelException {
		
		ArrayList<HotelBean> check;
		try{
		
		check=dao.hotelListDao();
		}catch(HotelException e){
			throw new HotelException("Error in displaying the hotel list");
		}
		return check;
	}
	@Override
	public ArrayList<HotelBean> hotelBookings(String hotel) throws HotelException {
		ArrayList<HotelBean> check;
		try{
		check=dao.hotelBookingDao(hotel);
		}catch(HotelException e){
			throw new HotelException("Error in providing the booking details");
		}
		return check;
	}
	@Override
	public ArrayList<HotelBean> hotelGuestList(String hotel3) throws HotelException {
		ArrayList<HotelBean> check;
		try{
		check=dao.hotelGuestList(hotel3);
		}catch(HotelException e){
			throw new HotelException("Error in displaying the guest list");
		}
		return check;
	}
	@Override
	public ArrayList<HotelBean> hotelDateBooking(String hotel4) throws HotelException {
		ArrayList<HotelBean> check;
		try{
		check=dao.hotelBookingDate(hotel4);
		}catch(HotelException e){
			throw new HotelException("Please provide valid details");
		}
		return check;
	}
	@Override
	public ArrayList<HotelBean> searchRooms(Date fromDate,Date toDate) throws HotelException {
		ArrayList<HotelBean> check;
		try{
		check=dao.searchRoomDao(fromDate,toDate);
		}catch(HotelException e){
			throw new HotelException("Error in searching room details. Pleasee provide valid room id");
		}
		return check;
	}
	@Override
	public String bookRoom(HotelBean bean) throws HotelException {
		String bookingId; 
		try{
			bookingId=	dao.bookRoom(bean);
		}catch(HotelException e){
			throw new HotelException("Error in booking room");
		}

		return bookingId;
	}
	@Override
	public float calculateAmount(Date from, Date to, float amount) throws HotelException {
		float netAmount;
		try{
			LocalDate from1=from.toLocalDate();
		LocalDate to1=to.toLocalDate();
		Period period=Period.between(from1, to1);
		int days=period.getDays();
		netAmount=(days)*amount;
		}catch(Exception e){
			throw new HotelException("Some thing went wrong. Please try again later");
		}
		return netAmount;
	}
	@Override
	public float getAmountByRoom(String roomId, String hotelId) throws HotelException {
		float amount = 0;
		try {
			amount = dao.getAmountByRoom(roomId,hotelId);
		} catch (HotelException e) {
			
			e.printStackTrace();
		}
		return amount;
	}
	@Override
	public Date getSqlDate(String date) throws HotelException {
		Date sqldate = null;
		try{
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate local=LocalDate.parse(date,format);
		sqldate=Date.valueOf(local);
		}catch(Exception e){
			
		}
		return sqldate;
	}
	@Override
	public Boolean changeAvailability(String hotelId, String roomId) throws HotelException {
		try{
			return dao.changeAvailablity(hotelId,roomId);
		}catch(HotelException e){
			throw new HotelException("Error in checking availability. Please enter valid details");
		}
		
	}
	@Override
	public HotelBean viewStatus(String bookingId) throws HotelException {
		
		HotelBean bean=new HotelBean();
		try{
		bean=dao.viewStatus(bookingId);
		}catch(HotelException e){
			throw new HotelException("Error in viewing status. Please provide valid details");
		}
		return bean;

	}



}
