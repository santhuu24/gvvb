

/*import java.util.*;
public class Test {
	public static void main(String[] args) {
		Map s1=new HashMap();
		s1.put("1","red");  
		s1.put("3","white"); 
		s1.put(null, "hello");
		s1.put("2","red");  
		s1.put("4","white");  
		s1.put(null, "hii");   
		System.out.println(s1);
		Map s2=new Hashtable();
		s2.put("1","red");  
		s2.put("3","white"); 
		s2.put(null, "hello");
		s2.put("2","red");  
		s2.put("4","white");  
		s2.put(null, "hii");   
		System.out.println(s2);
	}
}
public class Test {
	public static void main(String[] args) {
		ArrayList<String> s1=new ArrayList<String>();
		s1.add("red");  
		s1.add("white"); 
		s1.add(null);
		s1.add("red");  
		s1.add("white");  
		s1.add("null");   
		Iterator it=new s1.iterator();
		Iterator it1= s1.iterator();
		Iterator it2= new Iterator();	

		while(it1.hasNext()){
			System.out.print(it1.next()+" ");
		}
}
}*/

/*Set set = new TreeSet();
2). Set set = new HashSet();
3). Set set = new SortedSet();
4). List set = new SortedList();
5). Set set = new LinkedHashSet();*/

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.sql.*;
public class Test {
	public static void main(String[] args) {
		String query="SELECT customer_name, request_status,cab_number,address_of_pickup,date_of_request FROM cab_request WHERE request_id=?";
		  try{
		   PreparedStatement pstmt= con.prepareStatement(query);
		   pstmt.setInt(1, requestId);
		   ResultSet result=pstmt.executeQuery(query);
		 if(result.next())
		   {
		    System.out.println("Name of The Customer: "+result.getString(1));
		}}
		catch(SQLException se){
		System.out.println(se.getMessage());
		}
	}
}

