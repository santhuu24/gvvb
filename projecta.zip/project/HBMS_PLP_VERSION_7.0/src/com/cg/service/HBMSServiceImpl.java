package com.cg.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.IHBMSDao;
import com.cg.dto.BookingsDto;
import com.cg.dto.HotelDto;
import com.cg.dto.LoginDto;
import com.cg.dto.RoomDto;
import com.cg.exception.HotelException;

@Service("hbmsService")
@Transactional(rollbackFor = HotelException.class)
public class HBMSServiceImpl implements IHBMSService{

	@Autowired
	IHBMSDao hbmsDao;
	@Override
	public boolean validateLogin(String userid, String password) throws HotelException {

		return hbmsDao.validateLogin(userid,password);
	}
	@Override
	public int addNewHotel(HotelDto hotelDto) throws HotelException {

		return hbmsDao.addNewHotel(hotelDto);
	}
	@Override
	public List<HotelDto> getAllHotels() throws HotelException {

		return hbmsDao.getAllHotels();
	}
	@Override
	public void deleteHotel(int hotelId) throws HotelException {


		hbmsDao.deleteHotel(hotelId);

	}
	@Override
	public HotelDto retrieveHotelData(int hotelId) throws HotelException {

		return hbmsDao.retrieveHotelData(hotelId);
	}
	@Override
	public void updateHotel(HotelDto hotel) throws HotelException {
		 hbmsDao.updateHotel(hotel);

	}
	@Override
	public List<RoomDto> getAllRooms(int hotelId) throws HotelException {
		List<RoomDto> hotelRoomsList=hbmsDao.getAllRooms(hotelId);
		return hotelRoomsList;
	}
	@Override
	public void deleteRoom(int roomId) throws HotelException {
		
		hbmsDao.deleteRooms(roomId);
	}
	@Override
	public void addNewRoom(RoomDto roomDto) throws HotelException {
		hbmsDao.addNewRoom(roomDto);
		
	}
	@Override
	public RoomDto retrieveRoomDataById(int roomId) throws HotelException {
		
		return hbmsDao.retrieveRoomDataById(roomId);
	}
	@Override
	public RoomDto updateRooms(int roomId) throws HotelException {
		return hbmsDao.updateRooms(roomId);
	}
	@Override
	public void upadateRoomDetails(RoomDto roomDto) throws HotelException {
		hbmsDao.updateRoomDetails(roomDto);
		
	}
	@Override
	public List<BookingsDto> showDetailsForSpecificDate(String specificDate) throws HotelException {
		return hbmsDao.showDetailsForSpecificDate(specificDate);
	}
	@Override
	public List<BookingsDto> displayBookingsForSpecificHotel(int hotelId) throws HotelException {
		
		return hbmsDao.displayBookingsForSpecificHotel(hotelId);
	}
	@Override
	public List<BookingsDto> displayGuestListOfSpecificHotel(int hotelId) throws HotelException {
		
		return hbmsDao.displayGuestListOfSpecificHotel(hotelId);
	}
	@Override
	public List<LoginDto> getUserDetails(List<BookingsDto> bookingsDto) throws HotelException {
		
		return hbmsDao.getUserDetails(bookingsDto);
	}

}
