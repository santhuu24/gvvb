package com.cg.dao;

import java.util.Date;
import java.util.List;

import com.cg.dto.BookingsDto;
import com.cg.dto.HotelDto;
import com.cg.dto.LoginDto;
import com.cg.dto.RoomDto;
import com.cg.exception.HotelException;

public interface IHBMSDao {

	boolean validateLogin(String userid, String password) throws HotelException;



	int addNewHotel(HotelDto hotelDto) throws HotelException;



	List<HotelDto> getAllHotels() throws HotelException;



	void deleteHotel(int hotelId) throws HotelException;



	HotelDto retrieveHotelData(int hotelId) throws HotelException;



	void updateHotel(HotelDto hotel) throws HotelException;



	List<RoomDto> getAllRooms(int hotelId) throws HotelException;



	void deleteRooms(int roomId) throws HotelException;



	void addNewRoom(RoomDto roomDto) throws HotelException;



	RoomDto retrieveRoomDataById(int roomId) throws HotelException;



	RoomDto updateRooms(int roomId) throws HotelException;



	void updateRoomDetails(RoomDto roomDto) throws HotelException;



	List<BookingsDto> showDetailsForSpecificDate(String specificDate) throws HotelException;



	List<BookingsDto> displayBookingsForSpecificHotel(int hotelId) throws HotelException;



	List<BookingsDto> displayGuestListOfSpecificHotel(int hotelId) throws HotelException;



	List<LoginDto> getUserDetails(List<BookingsDto> bookingsDto) throws HotelException;

}
